import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;

public class testingColorsController {

    @FXML
    private Accordion accordion;
    
    @FXML
    private Button addStuff;

    @FXML
    private AnchorPane background;
    
    @FXML
    private AnchorPane task1;

    @FXML
    private Label boardTitle;
    
    @FXML
    private ColorPicker colorPicker;

    @FXML
    // changes color
    void changeColor(ActionEvent event) {
        Color myColor = colorPicker.getValue();
        task1.setBackground(new Background(new BackgroundFill(myColor, null, null)));
    }
}

