import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;

public class testController {

    @FXML
    private Accordion accordion;

    @FXML
    private Button addTaskBtn;

    @FXML
    private Label boardTitle;

    @FXML
    private Button deleteBtn;

    @FXML
    private TextField description;

    @FXML
    private AnchorPane kanbanWindow;

    @FXML
    private Button leftBtn;

    @FXML
    private Button righBtn;

    @FXML
    private Button saveBtn;

    @FXML
    private TitledPane task;

    @FXML
    private TitledPane title;
    

    @FXML
    private ColorPicker urgency;

    public void addTask(){
        TitledPane newTask = new TitledPane();
        AnchorPane taskback = new AnchorPane();
        TextArea taskText = new TextArea();

        taskText.setPrefHeight(50);
        taskText.setWrapText(true);
        newTask.setText("Task Name Here");
        newTask.setPrefWidth(300);
        newTask.setContent(taskback);
        newTask.setContent(taskText);
        
        
        accordion.getPanes().add(newTask);
    }    
        
    @FXML
    void btnAddTaskClicked(ActionEvent event) {
        addTask();
    }

    @FXML
    void btnDeleteClicked(ActionEvent event) {

    }

    @FXML
    void btnLeftClicked(ActionEvent event) {

    }

    @FXML
    void btnRightClicked(ActionEvent event) {

    }

    @FXML
    void btnSaveClicked(ActionEvent event) {

    }

    @FXML
    void urgencyCat(ActionEvent event) {

    }

}
