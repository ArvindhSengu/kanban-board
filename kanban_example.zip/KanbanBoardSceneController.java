import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import java.io.*;
import java.util.ResourceBundle;
import java.net.URL;
import javafx.stage.Stage;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import java.util.Scanner;

public class KanbanBoardSceneController implements Initializable{
    Parent root;
    Scene scene;
    Stage stage;

    @FXML
    private Button addTaskBtn;

    @FXML
    private Button archiveListBtn;

    @FXML
    private Label boardTitle;

    @FXML
    private TableColumn<?, ?> complete;

    @FXML
    private Button deleteBtn;

    @FXML
    private TextField description;

    @FXML
    private TableColumn<?, ?> Progress;

    @FXML
    private AnchorPane kanbanWindow;

    @FXML
    private Button leftBtn;
    
    @FXML
    private Button newCategoryBtn;

    @FXML
    private Button righBtn;

    @FXML
    private Button saveBtn;

    @FXML
    private TitledPane task;

    @FXML
    private TableColumn<?, ?> toDo;

    @FXML
    private ColorPicker urgency;

    @FXML
    void btnAddTaskClicked(ActionEvent event) throws IOException {
    
    }

    @FXML
    void btnArchiveListClicked(ActionEvent event) {

    }

    @FXML
    void btnDeleteClicked(ActionEvent event) {

    }

    @FXML
    void btnLeftClicked(ActionEvent event) {

    }

    @FXML
    void btnNewCatClicked(ActionEvent event) {

    }

    @FXML
    void btnRightClicked(ActionEvent event) {

    }

    @FXML
    FileChooser fileChooser = new FileChooser();
    
    void getDescription(MouseEvent event){
        File file = fileChooser.showOpenDialog(new Stage());
        try{
            Scanner scanner = new Scanner(file);
            while(scanner.hasNextLine()){
                description.appendText(scanner.nextLine() + "\n");
            }
        }catch(FileNotFoundException e ){
            e.printStackTrace();
        }
    }

    /**
     * Save progress and write kanban board info onto a txt file
     * @param event To indicate that the button has been clicked
     */
    @FXML
    void btnSaveClicked(ActionEvent event) {
        File file = fileChooser.showSaveDialog(new Stage());//start making file to put info in
        if(file != null){
            saveSystem(file, description.getText());
        }
    }

    public void saveSystem(File file, String content){
        try{
             PrintWriter printWriter = new PrintWriter(file);//write the file
             printWriter.write(content);
             printWriter.close();
            }catch (FileNotFoundException e ){
                e.printStackTrace();
            }
    }

    @FXML
    void urgencyCat(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        fileChooser.setInitialDirectory(new File("C:"));
    }

}
